package common;

import java.util.regex.Pattern;

/**
 * Created by Karthik S on 9/3/2016.
 */
public class Config {

    public static final String MAIN_URL = "http://vajralabs.com/Taxi/";
    public static final String SIGNUP_ROOT = "signup_POST.php";
    public static final String SIGNUP_PATIENT_ROOT = "signup_patient_POST.php";

    public static final String SIGNUP_CONFIRMATION_ROOT = "signup_confirmation.php";
    public static final String DOCTOR_LIST = "doctor_list.php";
    public static final String GET_APPOINTMENT = "get_appointment.php";
    public static final String POST_STATUS = "post_status.php";


    public static final String USER_LOGIN = "user_login.php";
    public static final String USER_LOGIN_DOCTOR = "user_login_doctor.php";





    // Directory name to store captured images and videos
    public static final String IMAGE_DIRECTORY_NAME = "Android File Upload";
    public static final String EMAIL = "kpfbanoreply@gmail.com";
    public static final String PASSWORD = "kpfba2016";
    public static String url_path = "http://kpfba.info/";

    public static boolean isValidEmaillId(String email) {

        return Pattern.compile("^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$").matcher(email).matches();
    }

}
