package common;

/**
 * Created by karthiks on 1/20/2017.
 */

public class CheckInternet {
}
