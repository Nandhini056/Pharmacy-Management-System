package common;

/**
 * Created by Karthik S on 9/6/2016.
 */
public interface Response {
    void processFinish(String output);
}
